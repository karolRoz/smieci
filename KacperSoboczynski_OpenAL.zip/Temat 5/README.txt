Proszę się nie przestraszyć tym Spaghetti Code, ale nie wiedziałem jak inaczej to zadanie ugryźć :D

Mam nadzieję także, że nie będzie problemu z odtworzeniem muzyki, ponieważ robiłem według czasu
a czas mi się różnił za każdym razem ( w zależności jak procesor szybko wykonywał polecenia )
Więc mam nadzieję, że na słabszym procesorze też zadziała ( bo nie mogłem/wiedziałem jak to sprawdzić)


w każdym razie jest zaimplementowane 20 sekund utworu The Weeknd - blinding lights


Nuty i muzyczka https://musescore.com/user/33801712/scores/5905576